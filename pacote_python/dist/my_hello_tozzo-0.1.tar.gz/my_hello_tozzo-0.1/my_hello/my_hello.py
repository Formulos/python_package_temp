def world:
	print("hello world!")
